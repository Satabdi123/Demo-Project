$(function () {
    $(document).on("click", "#searchBtn", function () {
        //showProgressBar();
        prepareJsonData();
       
    });
    
});

function showProgressBar() {
    var elem = document.getElementById("progress-bar-inc");
    var width = 1;
    var id = setInterval(frame,10);
    function frame() {
        if (width >= 100) {
            clearInterval(id);
        } else {
            width++;
            elem.style.width = width + '%';
            //$('#progress-bar-inc').html(width + '%');
        }
    }
}
function prepareJsonData() {
    var firstName = $.trim($("#firstName").val()),
     lastName = $.trim($("#lastName").val());
    var dataUrl = "";
    if (firstName != "" && lastName == "") {
        dataUrl = "https://data.cityofnewyork.us/resource/5scm-b38n.json?first_name="+firstName+"&last_name="+lastName
    } else if (firstName == "" && lastName != "") {
        dataUrl = "https://data.cityofnewyork.us/resource/5scm-b38n.json?last_name="+lastName
    } else if (firstName != "" && lastName != "") {
        dataUrl = "https://data.cityofnewyork.us/resource/5scm-b38n.json?first_name="+firstName+"&last_name="+lastName
    } else {
        dataUrl = "https://data.cityofnewyork.us/resource/5scm-b38n.json"
    }
    $.ajax({
        dataType: "json",
        url: dataUrl,
        data: {
        
        },
        success: function (res) {
            //$("div.dataContainerDiv").show();
            //alert($("div.dataContainerDiv").length)
            //console.log(JSON.stringify(res))
            //alert(res.length)
            
            
            setTimeout(function () {
                $("div.dataContainerDiv").show();
                var resultedHtml = "";
                if (res.length > 0) {
                    for (var i = 0; i < res.length; i++) {

                        dataObj = res[i]
                        firstName = dataObj.first_name,
                            lastName = dataObj.last_name,
                            listNo = dataObj.list_no,
                            exmNo = dataObj.exam_no,
                            listAgencyDesc = dataObj.list_agency_desc,
                            listTitleDesc = dataObj.list_title_desc,
                            publishedDate = dataObj.published_date;
                        var dataHtml = '<tr scope="row" class="dataTr"><td  class="alignLeft">' + firstName + '</td>\n\
            <td class="alignLeft">'+ lastName + '</td>\n\
            <td class="alignLeft">'+ listNo + '</td>\n\
            <td class="alignLeft">'+ exmNo + '</td>\n\
            <td class="alignLeft">'+ listAgencyDesc + '</td>\n\
            <td class="alignLeft">'+ listTitleDesc + '</td>\n\
            <td class="alignLeft">'+ publishedDate + '</td></tr>';
                        resultedHtml = resultedHtml + dataHtml;


                    }

                    if ($(".dataTr").length == 0) {
                        $("#mainTab tbody").append(resultedHtml);
                    } else {
                        $("#mainTab tbody").html("");
                        $("#mainTab tbody").append(resultedHtml);
                    }
                } else {
                    $("#mainTab tbody").html("No Data to Display");
                }
            }, 2000);
            setTimeout(function () {
                $(".progress").hide();
                var elemiPro = document.getElementById("progress-bar-inc");
                elemiPro.style.width = 0 + '%';
                //$('#progress-bar-inc').html(0 + '%');
            }, 2002)
        },
        beforeSend: function () {
            $(".progress").show();
            showProgressBar();            
        }


    })
    
}

